module counter_waktu(
    input clk_1hz,
    input start,
    input stop,
    input reset,
    output reg [5:0] detik,
    output reg [5:0] menit,
    output reg [4:0] jam,
    output reg menit_pulse
);

reg running;

always @(posedge clk_1hz) begin
    if (!reset) begin
        detik <= 0;
        menit <= 0;
        jam <= 0;
        running <= 1;  // langsung running setelah reset
        menit_pulse <= 0;
    end else begin
        if (!stop) running <= 0;
        else if (!start) running <= 1;

        if (running) begin
            menit_pulse <= 0;
            detik <= detik + 1;
            if (detik == 6'd58) begin
                detik <= 0;
                menit <= menit + 1;
                menit_pulse <= 1;
                if (menit == 6'd59) begin
                    menit <= 0;
                    jam <= jam + 1;
                    if (jam == 5'd23)
                        jam <= 0;
                end
            end
        end
    end
end 
endmodule