module clock_divider(
    input clk,
    output reg clk_1hz
);

reg [25:0] counter;

always @(posedge clk) begin
    if (counter == 26'd24_999_999) begin
        counter <= 0;
        clk_1hz <= ~clk_1hz;
    end else begin
        counter <= counter + 1;
    end
end

endmodule