module jam_digital(
    input clk,
    input S1,
    input S2,
    input S3,
    output reg [7:0] SEG,
    output reg [3:0] DIG,
    output LED0

);

wire clk_1hz;
wire [5:0] detik, menit;
wire [4:0] jam;
wire [7:0] seg_wire;

clock_divider u1(.clk(clk), .clk_1hz(clk_1hz));

counter_waktu u2(
    .clk_1hz(clk_1hz),
    .start(S1),
    .stop(S2),
    .reset(S3),
    .detik(detik),
    .menit(menit),
    .jam(jam),
    .menit_pulse(menit_pulse)
);

reg [3:0] digit_val;
reg [1:0] mux_sel;
reg [15:0] mux_counter;

always @(posedge clk) begin
    if (mux_counter == 16'd50000) begin
        mux_counter <= 0;
        mux_sel <= mux_sel + 1;
    end else begin
        mux_counter <= mux_counter + 1;
    end
end

always @(*) begin
    case (mux_sel)
        2'd0: begin DIG = 4'b1110; digit_val = detik % 10; end
        2'd1: begin DIG = 4'b1101; digit_val = detik / 10; end
        2'd2: begin DIG = 4'b1011; digit_val = menit % 10; end
        2'd3: begin DIG = 4'b0111; digit_val = menit / 10; end
    endcase
end

seg_decoder u3(.digit(digit_val), .seg(seg_wire));

always @(*) begin
    SEG = seg_wire;
end

assign LED0 = menit_pulse;

endmodule